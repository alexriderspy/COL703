Sreemanti Dey
2020CS10393

I haven't used any python libraries in my code.
